package com.examly.springapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Category;
import com.examly.springapp.service.CategoryService;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
    @Autowired
    private CategoryService service;

    @PostMapping
    public ResponseEntity<Category> storeCategory(@RequestBody Category category ){
        Category ca = service.storeCategory(category);
        return ResponseEntity.status(HttpStatus.CREATED).body(ca);
    }
    @GetMapping  
    public ResponseEntity<List<Category>> getAllCategory(){
        List<Category> l = service.getAllCategory();
        return ResponseEntity.ok(l);
    }
    @GetMapping("/{categoryId}")
    public ResponseEntity <Category> getCategory(@PathVariable Long categoryId){
        Category cat = service.getCategory(categoryId).get();
        return ResponseEntity.ok(cat);
    }
}
