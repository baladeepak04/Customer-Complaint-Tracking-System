package com.examly.springapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.service.CommentService;


@RestController
@RequestMapping("/api/comment")
public class CommentController {
    @Autowired
    private CommentService service;
}
