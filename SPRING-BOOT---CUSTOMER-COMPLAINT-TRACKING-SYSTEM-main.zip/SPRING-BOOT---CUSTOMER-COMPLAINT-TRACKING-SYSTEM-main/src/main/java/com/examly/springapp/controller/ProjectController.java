package com.examly.springapp.controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Project;
import com.examly.springapp.service.ProjectService;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {
    @Autowired
    private ProjectService service;
    @PostMapping
    public ResponseEntity<Project> storeProject(@RequestBody Project p){
        try{
            Project pro = service.storeProject(p);
            return ResponseEntity.status(HttpStatus.CREATED).body(pro);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        } 
    }
    @GetMapping
    public ResponseEntity<List<Project>> getAllprojects(){
        try{
            List<Project> project = service.getAllprojects();
            return ResponseEntity.status(HttpStatus.OK).body(project);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/{projectId}")
    public ResponseEntity<Optional<Project>> getProjects(@PathVariable Long projectId){
        try{
            Optional<Project> project = service.getProjects(projectId);
            return ResponseEntity.status(HttpStatus.OK).body(project);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @PutMapping("/{projectId}")
    public ResponseEntity<Project> updateProject(@PathVariable Long projectId, @RequestBody Project p){
        try{
            Project updated = service.updateProject(projectId,p);
            return ResponseEntity.status(HttpStatus.OK).body(updated);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getProStatus(@PathVariable String status){
        try{
            List<Project> list = service.getProStatus(status);

            if(list == null || list.isEmpty()){
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No projects found with status: " + status);
            }
            return ResponseEntity.status(HttpStatus.OK).body(list);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
