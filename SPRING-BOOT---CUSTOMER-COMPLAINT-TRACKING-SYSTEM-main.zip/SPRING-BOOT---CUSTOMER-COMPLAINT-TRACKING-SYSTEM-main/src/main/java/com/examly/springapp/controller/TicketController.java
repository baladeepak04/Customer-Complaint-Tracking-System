package com.examly.springapp.controller;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.Ticket;


import com.examly.springapp.service.TicketService;

@RestController
@RequestMapping("/api/ticket")
public class TicketController {
    @Autowired
    private TicketService service;
    @GetMapping("/{ticketId}")
    public ResponseEntity<Optional<Ticket>> getTicket(@PathVariable Long ticketId){
        try{
            Optional<Ticket> ticket = service.getTicket(ticketId);
            return ResponseEntity.status(HttpStatus.OK).body(ticket);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }


}
