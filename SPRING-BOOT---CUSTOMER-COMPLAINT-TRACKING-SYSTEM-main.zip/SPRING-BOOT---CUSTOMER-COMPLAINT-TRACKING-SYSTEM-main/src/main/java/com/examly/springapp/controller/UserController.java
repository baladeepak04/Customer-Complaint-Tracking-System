package com.examly.springapp.controller;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examly.springapp.model.User;

import com.examly.springapp.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService service;
    @PostMapping
    public ResponseEntity<User> addUser(@RequestBody User user){
        try{
            User use = service.storeUser(user);
            return ResponseEntity.status(HttpStatus.CREATED).body(use);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @GetMapping("/{userId}")
    public ResponseEntity<Optional<User>> getUser(@PathVariable Long userId){
        try{
            Optional<User> user = service.getUser(userId);
            return ResponseEntity.status(HttpStatus.OK).body(user);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers(){
        try{
            List<User> users = service.getAllUsers();
            return ResponseEntity.status(HttpStatus.OK).body(users);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id,@RequestBody User user){
        try{
            User u = service.updateUser(id, user);
            return ResponseEntity.status(HttpStatus.OK).body(u);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @GetMapping("/role/{role}")
    public ResponseEntity<?> getUserRole(@PathVariable String role){
        try{
            List<User> users = service.getUserRole(role);
            if(users.isEmpty()){
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("No users found with role: " + role);
            }
            return ResponseEntity.status(HttpStatus.OK).body(users);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @GetMapping("/email/{email}")
    public ResponseEntity<?> getUserEmail(@PathVariable String email){
        try{
            List<User> users = service.getUserEmail(email);
            if(users.isEmpty()){
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body("User not found with email: " + email);
            }
            return ResponseEntity.status(HttpStatus.OK).body(users);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @GetMapping("/page/{pageNo}/{pageSize}")
    public ResponseEntity<Page<User>> pageUser(@PathVariable int pageNo,@PathVariable int pageSize){
        try{
            Page<User> page = service.pageUser(pageNo, pageSize);
            return ResponseEntity.status(HttpStatus.OK).body(page);
        }
        catch(Exception obj){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    

    


}
