package com.examly.springapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examly.springapp.model.Comment;

public interface CommentRepo extends JpaRepository<Comment,Long> {

    
} 