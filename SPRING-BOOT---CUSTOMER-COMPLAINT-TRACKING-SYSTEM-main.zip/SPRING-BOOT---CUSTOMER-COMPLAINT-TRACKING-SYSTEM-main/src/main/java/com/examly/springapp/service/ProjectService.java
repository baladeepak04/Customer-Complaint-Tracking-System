package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.examly.springapp.model.Project;
import com.examly.springapp.repository.ProjectRepo;

@Service
public class ProjectService {
    @Autowired
    private ProjectRepo repo;

    public Project storeProject(Project p){
        return repo.save(p);
    }
    public List<Project> getAllprojects(){
        return repo.findAll();
    }
    public Optional<Project> getProjects(Long projectId){
        return repo.findById(projectId);
    }
    public Project updateProject(Long projectId,Project p){
        p.setProjectId(projectId);
        return repo.save(p);
    }
    public List<Project> getProStatus(String status){
        return repo.findByStatus(status);
    }
}
  