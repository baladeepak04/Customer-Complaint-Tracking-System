package com.examly.springapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepo;

@Service
public class UserService {
    @Autowired
    private UserRepo repo;

    public User storeUser(User username){
        return repo.save(username);
    }
    public List<User> getAllUsers(){
        return repo.findAll();
    }
    public Optional<User> getUser(Long userId){
        return repo.findById(userId);
    }
    public User updateUser(Long id,User u){
        u.setUserId(id);
        return repo.save(u);
    }
    public List<User> getUserRole(String role){
        return repo.findByRole(role);
    }
    public List<User> getUserEmail(String email){
        return repo.findByEmail(email);
    }
    public Page<User> pageUser(int pageNo,int pageSize){
        return repo.findAll(PageRequest.of(pageNo,pageSize));
    }


}
